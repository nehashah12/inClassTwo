document.getElementById("h2").innerHTML = "My Web Page";
function myFunction() {
    document.getElementById("java").style.fontSize = "25px";
    document.getElementById("java").style.color = "magenta";
}
$(document).ready (function () {
$("#tabs").tabs();
});

document.getElementById("random").innerHTML = Math.random();
